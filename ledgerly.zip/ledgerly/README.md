# Ledgerly

An accounting platform where **every client gets books shaped around their own business**: a poultry farm, a school, a sole proprietor, or anything you set up. You (the platform admin) onboard clients and customise their accounts and fields; each client's data is kept completely separate.

Amounts are in **Naira (₦)** by default and stored in kobo (whole numbers) so totals never drift.

---

## Run it on your computer

You need **Node.js 22.13 or newer** (https://nodejs.org). There is nothing else to install.

```bash
cd ledgerly
npm start
```

Then open **http://localhost:3000**.

1. Click **Create an account**. The **first** account created becomes the **platform admin** (you).
2. Click **Onboard new client**, choose **Poultry Farm**, type the farm's name, and (optionally) the owner's email.
3. Open the client and click **+ Money in** or **+ Money out** to start recording.

Your data lives in `data/ledgerly.db`. **Back this file up regularly**: copying it is a full backup.

To check everything works: `npm test`

---

## How it works (the 2-minute version)

- **Organisation** = one client business. Everything below belongs to exactly one organisation.
- **Chart of accounts** = the list of places money can come from or go to (e.g. *Egg Sales*, *Feed*, *Bank Account*). A client starts from a **template** and can then rename, add or switch off any account.
- **Custom fields** = extra questions on each transaction (e.g. *Flock / Batch*, *Class*, *Term*). Different for every client.
- **Transactions** come in three kinds:
  - **Money in**: sales and other income (into cash, bank, or "customers owing us" for credit sales)
  - **Money out**: expenses (from cash/bank, or "suppliers we owe" if bought on credit)
  - **Move money**: bank deposits, loans, owner putting in or taking out money, customers paying what they owed, paying suppliers
- Behind the scenes every transaction is a proper **double-entry** record, so the **Profit & Loss**, **Balance Sheet** and **Trial Balance** are always consistent.
- Mistakes are **voided**, never deleted, so there is always an audit trail.

### Roles

| Role | Can do |
|---|---|
| **Platform admin** (you) | Onboard clients, open and configure any client |
| **Owner** (client) | Everything inside their organisation: accounts, fields, team |
| **Accountant** | Record and void transactions, view reports |
| **Viewer** | View only |

Add people from **Team**. If they haven't signed up yet, their access switches on automatically when they register with that email.

---

## Adding a new type of business

Open `templates.js`. Copy any block (for example `school`), give it a new key (such as `church`), then change the account list and the fields. Restart the server and the new type appears when onboarding a client. Existing clients are not affected.

You don't need a template for one-off needs: after onboarding, any client's accounts and fields can be changed from the **Chart of accounts** and **Custom fields** pages.

---

## Putting it online (before real clients use it)

1. Host it on any server that can run Node 22 (Render, Railway, Fly.io, a VPS…). Use a **persistent disk/volume** for the `data` folder, otherwise the database is lost on restart.
2. Set these environment variables:
   - `NODE_ENV=production` (makes login cookies HTTPS-only)
   - `ADMIN_EMAIL=you@yourdomain.com` so **only you** can ever be the platform admin, instead of "whoever signs up first"
   - `PORT` (if your host requires one)
3. Serve it over **HTTPS** (most hosts do this automatically).
4. Set up automatic backups of `data/ledgerly.db`.

### What's built in for safety
- Passwords are hashed with scrypt; login attempts are rate-limited.
- Every request checks the person's role for that specific organisation, and one client can never read or write another's data.
- All text shown on screen is escaped, the app sends a strict Content-Security-Policy, and changes can't be forged from other websites.
- CSV exports neutralise spreadsheet-formula tricks.

### Not built yet (good next steps)
- Password reset by email, and email invitations
- Invoices & receipts (PDF), customer/supplier records
- Bank statement import and reconciliation
- Closing a period (locking past months)
- Inventory/flock tracking, payroll, student fee ledgers
- Multi-currency conversion, per-client logo and branding

---

## Files

| File | What it is |
|---|---|
| `server.js` | The server: database, logins, permissions, accounting rules, reports |
| `templates.js` | The starting accounts and fields for each business type |
| `public/` | The website: `index.html`, `style.css`, `app.js` |
| `test/smoke.test.js` | Automated checks (a poultry-farm walkthrough, permissions, security) |
| `data/` | Created on first run; holds your database |
