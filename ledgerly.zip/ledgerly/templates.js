'use strict';

/*
 * ORGANISATION TEMPLATES
 * ----------------------
 * Each template is the *starting point* for a new client. After a client is
 * created from a template, you (the platform admin) or the client's owner can
 * add, rename or switch off any account and custom field - nothing is locked.
 *
 * accounts: [code, name, type, tag]
 *   type: asset | liability | equity | income | expense
 *   tag (optional): 'cash' | 'receivable' | 'payable'
 *         - the dashboard uses these to show "Money on hand",
 *           "Owed to you" and "You owe".
 *
 * fields: extra questions asked on every transaction for this client.
 *   type: text | number | select | date
 *
 * To add a new type of business (e.g. a church, a transport company), copy one
 * of the blocks below, change the lists and give it a new key.
 */

const TEMPLATES = {
  poultry_farm: {
    label: 'Poultry Farm',
    description: 'Layers and broilers: eggs, live birds, feed, vaccines, flock batches.',
    accounts: [
      ['1000', 'Cash on Hand', 'asset', 'cash'],
      ['1010', 'Bank Account', 'asset', 'cash'],
      ['1020', 'Mobile Money / POS', 'asset', 'cash'],
      ['1100', 'Customers Owing Us (Receivable)', 'asset', 'receivable'],
      ['1200', 'Feed in Store', 'asset', null],
      ['1210', 'Drugs & Vaccines in Store', 'asset', null],
      ['1300', 'Birds in Stock (Flock Value)', 'asset', null],
      ['1500', 'Poultry Houses & Cages', 'asset', null],
      ['1510', 'Equipment, Generator & Vehicles', 'asset', null],
      ['2000', 'Suppliers We Owe (Payable)', 'liability', 'payable'],
      ['2100', 'Loans Payable', 'liability', null],
      ['3000', "Owner's Capital", 'equity', null],
      ['3100', "Owner's Drawings", 'equity', null],
      ['4000', 'Egg Sales', 'income', null],
      ['4010', 'Broiler / Live Bird Sales', 'income', null],
      ['4020', 'Spent Layer (Cull) Sales', 'income', null],
      ['4030', 'Day-Old Chick Sales', 'income', null],
      ['4040', 'Poultry Manure Sales', 'income', null],
      ['4900', 'Other Income', 'income', null],
      ['5000', 'Feed', 'expense', null],
      ['5010', 'Day-Old Chicks / Point-of-Lay Purchase', 'expense', null],
      ['5020', 'Vaccines & Medication', 'expense', null],
      ['5030', 'Veterinary Fees', 'expense', null],
      ['5040', 'Labour & Wages', 'expense', null],
      ['5050', 'Water & Electricity', 'expense', null],
      ['5060', 'Diesel / Petrol (Generator)', 'expense', null],
      ['5070', 'Transport & Delivery', 'expense', null],
      ['5080', 'Litter / Wood Shavings', 'expense', null],
      ['5090', 'Repairs & Maintenance', 'expense', null],
      ['5100', 'Bird Mortality Loss', 'expense', null],
      ['5110', 'Egg Crates & Packaging', 'expense', null],
      ['5120', 'Bank Charges', 'expense', null],
      ['5900', 'Other Expenses', 'expense', null],
    ],
    fields: [
      { label: 'Flock / Batch', type: 'text', required: false },
      { label: 'House / Pen', type: 'text', required: false },
      { label: 'Quantity', type: 'number', required: false },
      { label: 'Unit', type: 'select', options: ['Crates', 'Birds', 'Bags', 'Kg', 'Litres', 'Trays'], required: false },
    ],
  },

  crop_farm: {
    label: 'Crop / Mixed Farm',
    description: 'Crops and livestock by season: seed, fertiliser, labour, harvest sales.',
    accounts: [
      ['1000', 'Cash on Hand', 'asset', 'cash'],
      ['1010', 'Bank Account', 'asset', 'cash'],
      ['1100', 'Customers Owing Us (Receivable)', 'asset', 'receivable'],
      ['1200', 'Seeds, Fertiliser & Chemicals in Store', 'asset', null],
      ['1300', 'Harvested Produce in Store', 'asset', null],
      ['1500', 'Land Improvements & Buildings', 'asset', null],
      ['1510', 'Tractors, Tools & Equipment', 'asset', null],
      ['2000', 'Suppliers We Owe (Payable)', 'liability', 'payable'],
      ['2100', 'Loans Payable', 'liability', null],
      ['3000', "Owner's Capital", 'equity', null],
      ['3100', "Owner's Drawings", 'equity', null],
      ['4000', 'Crop Sales', 'income', null],
      ['4010', 'Livestock Sales', 'income', null],
      ['4020', 'Produce Processing Sales', 'income', null],
      ['4030', 'Grants & Subsidies', 'income', null],
      ['4900', 'Other Income', 'income', null],
      ['5000', 'Seeds & Seedlings', 'expense', null],
      ['5010', 'Fertiliser', 'expense', null],
      ['5020', 'Pesticides & Herbicides', 'expense', null],
      ['5030', 'Casual & Permanent Labour', 'expense', null],
      ['5040', 'Land Preparation / Tractor Hire', 'expense', null],
      ['5050', 'Irrigation, Fuel & Power', 'expense', null],
      ['5060', 'Animal Feed & Veterinary', 'expense', null],
      ['5070', 'Transport & Haulage', 'expense', null],
      ['5080', 'Storage & Post-Harvest Loss', 'expense', null],
      ['5090', 'Repairs & Maintenance', 'expense', null],
      ['5120', 'Bank Charges', 'expense', null],
      ['5900', 'Other Expenses', 'expense', null],
    ],
    fields: [
      { label: 'Field / Plot', type: 'text', required: false },
      { label: 'Crop / Animal', type: 'text', required: false },
      { label: 'Season', type: 'select', options: ['Rainy', 'Dry', 'Year-round'], required: false },
    ],
  },

  school: {
    label: 'School',
    description: 'Fees by term and student, salaries, PTA levies, school running costs.',
    accounts: [
      ['1000', 'Cash on Hand', 'asset', 'cash'],
      ['1010', 'Bank Account', 'asset', 'cash'],
      ['1100', 'Fees Owed by Parents (Receivable)', 'asset', 'receivable'],
      ['1200', 'Books, Uniforms & Stationery Stock', 'asset', null],
      ['1500', 'School Buildings & Furniture', 'asset', null],
      ['1510', 'Computers, Buses & Equipment', 'asset', null],
      ['2000', 'Suppliers We Owe (Payable)', 'liability', 'payable'],
      ['2050', 'Fees Paid in Advance by Parents', 'liability', null],
      ['2100', 'Loans Payable', 'liability', null],
      ['3000', "Proprietor's Capital", 'equity', null],
      ['3100', "Proprietor's Drawings", 'equity', null],
      ['4000', 'Tuition Fees', 'income', null],
      ['4010', 'Registration & Admission Fees', 'income', null],
      ['4020', 'Books, Uniform & Stationery Sales', 'income', null],
      ['4030', 'Exam, Lesson & Extra-Curricular Fees', 'income', null],
      ['4040', 'PTA / Development Levy', 'income', null],
      ['4050', 'School Bus Fees', 'income', null],
      ['4900', 'Other Income', 'income', null],
      ['5000', 'Teachers’ Salaries', 'expense', null],
      ['5010', 'Non-Teaching Staff Wages', 'expense', null],
      ['5020', 'Teaching Materials & Stationery', 'expense', null],
      ['5030', 'Water & Electricity', 'expense', null],
      ['5040', 'Diesel / Generator', 'expense', null],
      ['5050', 'Rent', 'expense', null],
      ['5060', 'Repairs & Maintenance', 'expense', null],
      ['5070', 'Examination Expenses (WAEC/NECO etc.)', 'expense', null],
      ['5080', 'Bus Fuel & Maintenance', 'expense', null],
      ['5090', 'Security & Cleaning', 'expense', null],
      ['5100', 'Bad Debts / Fee Waivers & Scholarships', 'expense', null],
      ['5120', 'Bank Charges', 'expense', null],
      ['5900', 'Other Expenses', 'expense', null],
    ],
    fields: [
      { label: 'Student ID / Name', type: 'text', required: false },
      { label: 'Class', type: 'text', required: false },
      { label: 'Term', type: 'select', options: ['First Term', 'Second Term', 'Third Term'], required: false },
      { label: 'Session (e.g. 2026/2027)', type: 'text', required: false },
    ],
  },

  sole_proprietor: {
    label: 'Sole Proprietorship / Small Business',
    description: 'Shops, traders, artisans, freelancers: simple sales and expenses.',
    accounts: [
      ['1000', 'Cash on Hand', 'asset', 'cash'],
      ['1010', 'Bank Account', 'asset', 'cash'],
      ['1020', 'Mobile Money / POS', 'asset', 'cash'],
      ['1100', 'Customers Owing Us (Receivable)', 'asset', 'receivable'],
      ['1200', 'Goods / Stock on Hand', 'asset', null],
      ['1500', 'Shop, Tools & Equipment', 'asset', null],
      ['2000', 'Suppliers We Owe (Payable)', 'liability', 'payable'],
      ['2100', 'Loans Payable', 'liability', null],
      ['3000', "Owner's Capital", 'equity', null],
      ['3100', "Owner's Drawings", 'equity', null],
      ['4000', 'Sales', 'income', null],
      ['4010', 'Service Income', 'income', null],
      ['4900', 'Other Income', 'income', null],
      ['5000', 'Cost of Goods Sold / Purchases', 'expense', null],
      ['5010', 'Rent', 'expense', null],
      ['5020', 'Staff Wages', 'expense', null],
      ['5030', 'Transport & Delivery', 'expense', null],
      ['5040', 'Electricity & Generator Fuel', 'expense', null],
      ['5050', 'Data, Airtime & Internet', 'expense', null],
      ['5060', 'Marketing & Advertising', 'expense', null],
      ['5070', 'Repairs & Maintenance', 'expense', null],
      ['5080', 'Taxes, Levies & Licences', 'expense', null],
      ['5120', 'Bank Charges', 'expense', null],
      ['5900', 'Other Expenses', 'expense', null],
    ],
    fields: [
      { label: 'Customer / Supplier', type: 'text', required: false },
      { label: 'Invoice / Receipt No.', type: 'text', required: false },
    ],
  },

  blank: {
    label: 'Blank (build from scratch)',
    description: 'Only cash, bank, capital, sales and a few expenses. Customise everything.',
    accounts: [
      ['1000', 'Cash on Hand', 'asset', 'cash'],
      ['1010', 'Bank Account', 'asset', 'cash'],
      ['1100', 'Customers Owing Us (Receivable)', 'asset', 'receivable'],
      ['2000', 'Suppliers We Owe (Payable)', 'liability', 'payable'],
      ['3000', "Owner's Capital", 'equity', null],
      ['3100', "Owner's Drawings", 'equity', null],
      ['4000', 'Income', 'income', null],
      ['5000', 'Expenses', 'expense', null],
    ],
    fields: [],
  },
};

module.exports = { TEMPLATES };
